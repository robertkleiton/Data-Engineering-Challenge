#!usr/bin/python
# coding: utf-8

import psycopg2.extras as pse
import pandas as pd
import os
import log
import tempfile
import pyarrow
import query_insert as qr
import connect as con
import sys

def insert_stg(file_input, query_input):
    conn = con.connect_db()
    cursor = conn.cursor()
    try:
        file_path = tempfile.gettempdir() +'/'+ file_input
        data_parquet = pd.read_parquet(file_path, engine='pyarrow')
        log.logger.info(file_input + ' input')
        try:
            pse.execute_batch(cursor, query_input,
            data_parquet.loc[:].values, page_size= 10000)
            conn.commit()
        except Exception as erro:
            log.logger.error(erro)
            log.logger.error(data_parquet.loc[:, ].values)
            sys.exit()
    except IOError as erro:
        log.logger.error(erro)
        conn.close()

    conn.close()