#!usr/bin/python
# coding: utf-8
import psycopg2
import sys
import os

hst = "<host RDS>"
db = "<database>"
usr = "<user>"
psw = "<pass>"

def connect_db():
	conn = psycopg2.connect("dbname='%s' user='%s' host='%s' password='%s'" % (db, usr, hst, psw))
	return conn
