#!usr/bin/python
# -*- encoding: utf-8-*-

import pandas as pd
import glob
import boto3
import os
import tempfile
import json
from pathlib import Path
import datetime
import pytz
import pyarrow
import variables as var
import log

# import log
path_tmp = tempfile.gettempdir()

log.logger.info('connect S3...')
# session = boto3.Session(aws_access_key_id = os.environ['access_key'], aws_secret_access_key = os.environ['secret_access_key'])
session = boto3.Session(aws_access_key_id = var.access_key, aws_secret_access_key = var.secret_access_key)
s3_resource = session.resource('s3')

current_date = datetime.datetime.now(pytz.timezone('America/Sao_Paulo'))
hour = (current_date + datetime.timedelta(hours=0)).strftime('%H')
day = str(current_date.strftime('%d'))
month = str(current_date.strftime('%m'))
year = current_date.strftime('%Y')
tt = str(current_date.strftime('%H%M%S%f'))
data = str(current_date.strftime('%Y%m%d'))

# Tratamento e upload
    
files_ = glob.glob(path_tmp+'/*')

def read_dataset(bucket, prefix, files_dist = files_, ):
    for file_ in files_dist:
        if file_.endswith('.jsonl'):
            read_jsonl(file_, bucket, prefix)
        elif file_.endswith('.csv'):
            read_csv(file_, bucket, prefix)
          
def read_csv(file, bucket, prefix_output):
    try:
        log.logger.info('read and proccess dataset.. {}'.format(file[5:-4]))
        df = pd.read_csv(file, sep=',', dtype=str)
        df.columns = map(str.lower, df.columns)
        file_input = file[5:-4]
        path_output = prefix_output.format(year, month, day) % (file_input, file_input)
        parquet_file = path_tmp + '/'+ file_input + '.snappy.parquet'
        try:
            log.logger.info('save dataset to S3...')
            df.to_parquet(parquet_file, engine='pyarrow', compression='snappy')
            s3_resource.meta.client.upload_file(Filename = parquet_file, Bucket = bucket, Key = path_output  + '.snappy.parquet')
        except Exception as erro:
            log.logger.error(erro)
    except Exception as erro:
        log.logger.error(erro)


def read_jsonl(file, bucket, prefix_output):
        try:
            log.logger.info('read and proccess dataset.. {}'.format(file[5:-4]))
            crude_file = open(file).read()
            result = {
                    "sucesso": [],
                    "erro": []
            }
            for i in crude_file.splitlines():
                    try:
                            result['sucesso'].append(json.loads(i))
                    except:
                            # log.logger.warning('Error in json loads {}'.format(i))
                            result['erro'].append(i)
            df = pd.DataFrame(result['sucesso'])
            # df.columns = map(str.lower, df.columns)
            file_input = file[5:-6]
            path_output = prefix_output.format(year, month, day) % (file_input, file_input)
            parquet_file = path_tmp + '/'+ file_input + '.snappy.parquet'
            try:
                df.to_parquet(parquet_file, engine='pyarrow', compression='snappy')
                s3_resource.meta.client.upload_file(Filename = parquet_file, Bucket = bucket, Key = path_output  + '.snappy.parquet')
            except Exception as erro:
                log.logger.error(erro)
        except Exception as erro:
            log.logger.error(erro)