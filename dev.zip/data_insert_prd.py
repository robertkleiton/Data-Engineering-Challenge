#!usr/bin/python
# coding: utf-8

import pandas as pd
import os
import connect as con
import log
import variables as var
import sys

def insert_prd(query_update_insert):
    conn = con.connect_db()
    cursor = conn.cursor()
    try:
        log.logger.info('Insert ' + query_update_insert[16:-4])
        query = open(query_update_insert, 'r').read()
        cursor.execute(query)
        conn.commit()
    except Exception as erro:
        log.logger.error(erro)
		sys.exit()
        conn.close()
