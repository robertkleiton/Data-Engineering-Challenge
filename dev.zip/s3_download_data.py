import glob
import boto3
import os
import tempfile
import tarfile
from pathlib import Path
import log
import sys
import variables as var


def s3_download_dataset(bucket, path_input):

    # S3
    log.logger.info('connect S3...')
    session = boto3.Session(aws_access_key_id = var.access_key, aws_secret_access_key = var.secret_access_key)
    s3_resource = session.resource('s3')

    tmp = tempfile.NamedTemporaryFile()
    path_tmp = tempfile.gettempdir()
    try:
        log.logger.info('extract datasets from S3....')
        s3_resource.meta.client.download_file(Filename = tmp.name+'.tar.gz', Bucket = bucket, Key = path_input)
    except Exception as erro:
        log.logger.error(erro)
        sys.exit()
    
    tar = tarfile.open(tmp.name+'.tar.gz')
    tar.extractall(path_tmp)
    tar.close()