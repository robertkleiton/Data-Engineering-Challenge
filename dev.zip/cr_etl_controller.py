import os
import log
import variables as var
import query_insert as qr
import s3_download_data as sdd
import process_data_up_s3 as pdus
import truncate_tables as tr
import data_insert_stg as dis
import data_insert_prd as dip


# Extracao de arquivos no bucket S3 para processamento
sdd.s3_download_dataset(var.bucket, var.path_input)

# Processamento, tratamento e updload dos arquivos no bucket S3, em formato .parquet 
pdus.read_dataset(var.bucket, var.path_output)

#Truncanto tabelas stages
tr.truncate()

# Inserindo dados cru nas tabelas stage para tratamento interno
dis.insert_stg(var.dca_dataset_loan_transactions, qr.query_dca_dataset_loan_transactions)

dis.insert_stg(var.dca_dataset_utilization_and_claims, qr.query_dca_dataset_utilization_and_claims)

dis.insert_stg(var.hdi_human_development_index_hdig_value, qr.query_hdi_human_development_index_hdig_value)

dis.insert_stg(var.world_currencies_conversion_rates, qr.query_world_currencies_conversion_rates)


# Inserindo / atualizando dados tratados nas tabelas public.

dip.insert_prd(var.insert_dca_dataset_loan_transactions)
dip.insert_prd(var.insert_dca_dataset_utilization_and_claims)
dip.insert_prd(var.insert_hdi_human_development_index_hdig_value)
dip.insert_prd(var.insert_world_currencies_conversion_rates)