
# S3 Bucet Access

bucket = '<bucket>'
access_key = '<access_key>'
secret_access_key = '<secret_access_key>'


file_input = 'datasets.tar.gz'
path_input = 'files_raw/datasets.tar.gz'
path_output = 'distribution_data/%s/year={}/month={}/day={}/%s'


# Datasets for proccess

dca_dataset_loan_transactions = 'dca_dataset_loan_transactions.snappy.parquet'
dca_dataset_utilization_and_claims = 'dca_dataset_utilization_and_claims.snappy.parquet'
hdi_human_development_index_hdig_value = 'hdi_human_development_index_hdig_value.snappy.parquet'
world_currencies_conversion_rates = 'world_currencies_conversion_rates.snappy.parquet'


# Datasets insert into database

insert_dca_dataset_loan_transactions = './query_sql_prd/dca_dataset_loan_transactions.sql'
insert_dca_dataset_utilization_and_claims = './query_sql_prd/dca_dataset_utilization_and_claims.sql'
insert_hdi_human_development_index_hdig_value = './query_sql_prd/hdi_human_development_index_hdig_value.sql'
insert_world_currencies_conversion_rates = './query_sql_prd/world_currencies_conversion_rates.sql'