INSERT INTO "public"."hdi_human_development_index_hdig_value"
(
	"country",
	"country_code",
	"id",
	"indicator",
	"indicator_code",
	"utc_created",
	"utc_updated",
	"value",
	"year",
	"date_creation"
)
select
	case when "country" = '' then null else "country"::varchar(100) end as "country",
	case when "country_code" = '' then null else "country_code"::varchar(10) end as "country_code",
	case when "id" = '' then null else "id"::int4 end as "id",
	case when "indicator" = '' then null else "indicator"::varchar(100) end as "indicator",
	case when "indicator_code" = '' then null else "indicator_code"::int4 end as "indicator_code",
	case when "utc_created" = '' then null else "utc_created"::timestamp end as "utc_created",
	case when "utc_updated" = '' then null else "utc_updated"::timestamp end as "utc_updated",
	case when "value" = '' then null else "value"::numeric end as "value",
	case when "year" = '' then null else "year"::varchar(4) end as "year",
	current_timestamp
from
	"stage"."hdi_human_development_index_hdig_value"
group by
	"country",
	"country_code",
	"id",
	"indicator",
	"indicator_code",
	"utc_created",
	"utc_updated",
	"value",
	"year"
on conflict on constraint "hdi_human_development_index_hdig_value_un"
do update set
	"country" = excluded."country",
	"country_code" = excluded."country_code",
	"id" = excluded."id",
	"indicator" = excluded."indicator",
	"indicator_code" = excluded."indicator_code",
	"utc_created" = excluded."utc_created",
	"utc_updated" = excluded."utc_updated",
	"value" = excluded."value",
	"year" = excluded."year",
	"last_update" = current_timestamp;