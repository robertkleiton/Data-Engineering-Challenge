INSERT INTO "public"."world_currencies_conversion_rates"
(
	"location",
	"indicator",
	"suject",
	"measure",
	"frequency",
	"time",
	"value",
	"flag_codes",
	"date_creation"
)
select
	case when "location" = '' then null else "location"::varchar(10) end as "location",
	case when "indicator" = '' then null else "indicator"::varchar(50) end as "indicator",
	case when "suject" = '' then null else "suject"::varchar(10) end as "suject",
	case when "measure" = '' then null else "measure"::varchar(50) end as "measure",
	case when "frequency" = '' then null else "frequency"::varchar(5) end as "frequency",
	case when "time" = '' then null else "time"::varchar(5) end as "time",
	case when "value" = '' then null else "value"::numeric end as "value",
	case when "flag_codes" = '' then null else "flag_codes"::varchar(50) end as "flag_codes",
	current_timestamp
from
	"stage"."world_currencies_conversion_rates"
group by
	"location",
	"indicator",
	"suject",
	"measure",
	"frequency",
	"time",
	"value",
	"flag_codes"
on conflict on constraint world_currencies_conversion_rates_un
do update set
	"location" = excluded."location",
	"indicator" = excluded."indicator",
	"suject" = excluded."suject",
	"measure" = excluded."measure",
	"frequency" = excluded."frequency",
	"time" = excluded."time",
	"value" = excluded."value",
	"flag_codes" = excluded."flag_codes",
	"last_update" = current_timestamp;