SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH




cd /home/ec2-user/etl/etl_creditas/
python cr_etl_controller.py
