import os
import connect as con
import variables as var
import log

# truncate tables stg and aux
def truncate():
    tables_truncate_list = [var.dca_dataset_loan_transactions[:-15], var.dca_dataset_utilization_and_claims[:-15],
                            var.hdi_human_development_index_hdig_value[:-15], var.world_currencies_conversion_rates[:-15]]
    log.logger.info('begin truncating tables')
    for tables in tables_truncate_list:
        # print(tables)
        conn = con.connect_db()
        cursor = conn.cursor()
        cursor.execute('truncate table stage.' + tables)
        conn.commit()
        conn.close()
    